/*
 * Copyright (c) 2021.  Hurricane Development Studios
 */

package com.app.videodownloadappv1hurricandev.utils;

public interface PermissionRequestCodes {
    int DOWNLOADS = 4444;
}
