/*
 * Copyright (c) 2021.  Hurricane Development Studios
 */

package com.app.videodownloadappv1hurricandev.download;

public interface Tracking {
    void startTracking();
    void stopTracking();
}
