/*
 * Copyright (c) 2021.  Hurricane Development Studios
 */

package com.hurricaneDev.videoDownloader.history;

public class VisitedPage {
    public String title;
    public String link;
}
